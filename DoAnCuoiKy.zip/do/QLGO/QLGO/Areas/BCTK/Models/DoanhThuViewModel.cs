﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLGO.Areas.BCTK.Models
{
    public class DoanhThuViewModel
    {
        public string ThangNam { get; set; }
        public decimal DoanhThu { get; set; }
    }
}