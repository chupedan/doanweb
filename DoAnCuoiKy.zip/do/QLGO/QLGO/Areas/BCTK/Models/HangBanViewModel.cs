﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLGO.Areas.BCTK.Models
{
    public class HangBanViewModel
    {
        public string ThangNam { get; set; }
        public string TenSP { get; set; }
        public int SoLuongBan { get; set; }
    }
}